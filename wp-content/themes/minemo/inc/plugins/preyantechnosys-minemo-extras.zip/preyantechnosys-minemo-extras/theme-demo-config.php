<?php

if ( ! function_exists( 'ocdi_import_files' ) ) {
  function ocdi_import_files() {
    return array(
      array(
        'import_file_name'             => 'overlay',
        'categories'                   => array( 'Overlay Site' ),
        'local_import_file'            => plugin_dir_path( __FILE__ ) . 'demo-content/demo.xml',
        'import_preview_image_url'     => plugin_dir_url( __FILE__ ) . 'demo-content/images/layout-overlay.png',
        'preview_url'                  => 'https://minemo.preyantechnosys.com/',
        'has_slider'                   => true,
      ),
	array(
        'import_file_name'             => 'classic',
        'categories'                   => array( 'Classic Site' ),
        'local_import_file'            => plugin_dir_path( __FILE__ ) . 'demo-content/demo.xml',
        'import_preview_image_url'     => plugin_dir_url( __FILE__ ) . 'demo-content/images/layout-classic.png',
        'has_slider'                   => true,
      ),
    );
  }
}
add_filter( 'ocdi/import_files', 'ocdi_import_files' );

// Automatically assign "Front page", "Posts page" and menu locations after the importer is done
// Import Revolution Slider if plugin is active
if ( ! function_exists( 'minemo_demo_after_import' ) ) {
  function minemo_demo_after_import($selected_import) {
  	// Assign menus to their locations.
  	$main_menu = get_term_by( 'name', 'Main menu', 'nav_menu' );
    $footer_menu = get_term_by( 'name', 'Footer menu', 'nav_menu' );

  	set_theme_mod( 'nav_menu_locations', array(
  		'preyantechnosys-main-menu' => $main_menu->term_id,
        'preyantechnosys-footer-menu' => $footer_menu->term_id,
  		)
  	);
	
	// Import custom configuration
	$content = file_get_contents($selected_import["local_import_file"] );
		
	if ( false !== strpos( $content, '<wp:theme_custom>' ) ) {
		preg_match('|<wp:theme_custom>(.*?)</wp:theme_custom>|is', $content, $config);
		if ($config && is_array($config) && count($config) > 1){
			$config = unserialize(base64_decode($config[1]));
			if (is_array($config)){
				$configs = array(
						'page_for_posts',
						'show_on_front',
						'page_on_front',
						'posts_per_page',
						'sidebars_widgets',
					);
				foreach ($configs as $item){
					if (isset($config[$item])){
						if( $item=='page_for_posts' || $item=='page_on_front' ){
							$page = get_page_by_title( $config[$item] );
							if( isset($page->ID) ){
								$config[$item] = $page->ID;
							}
						}
						update_option($item, $config[$item]);
					}
				}
				if (isset($config['sidebars_widgets'])){
					$sidebars = $config['sidebars_widgets'];
					update_option('sidebars_widgets', $sidebars);
					// read config
					$sidebars_config = array();
					if (isset($config['sidebars_config'])){
						$sidebars_config = $config['sidebars_config'];
						if (is_array($sidebars_config)){
							foreach ($sidebars_config as $name => $widget){
								update_option('widget_'.$name, $widget);
							}
						}
					}
				}						
			}
		}
	}
			
    // Configure permalinks
    global $wp_rewrite;
  	$wp_rewrite->set_permalink_structure( '/%postname%/' );
    flush_rewrite_rules();

    // Import Slider Revolution
    if ( class_exists( 'RevSlider' ) ) {
		
		// List of slider backup ZIP that we will import
			$slider_array	= array(
				plugin_dir_path( __FILE__ ) . 'demo-content/sliders/mainslider2.zip',
				plugin_dir_path( __FILE__ ) . 'demo-content/sliders/homeshopslider.zip',
			);

        $slider = new RevSlider();

        foreach($slider_array as $filepath){
          $slider->importSliderFromPost(true,true,$filepath);
        }

        echo ' Slider processed';
    }
	
	
	/**** Breacrumb NavXT related changes ****/
	$breadcrumb_navxt_settings						= array();
	$breadcrumb_navxt_settings['hseparator']		= ' &gt; ';  // General > Breadcrumb Separator
	$breadcrumb_navxt_settings['Hhome_template']	= '<span property="itemListElement" typeof="ListItem"><a property="item" typeof="WebPage" title="Go to %title%." href="%link%" class="%type%" bcn-aria-current>Home<span class="hide">%htitle%</span></a><meta property="position" content="%position%"></span>';  // General > Home Template
	$breadcrumb_navxt_settings['Hhome_template_no_anchor']	= '<span property="itemListElement" typeof="ListItem"><span property="name" class="%type%">%htitle%</span><meta property="url" content="%link%"><meta property="position" content="%position%"></span>';  // General > Home Template
	
	// Getting existing settings
	$bcn_options    = get_option('bcn_options');
	if( !empty($bcn_options) && is_array($bcn_options) ){
		// options already exists... so merging changes with existing options
		$breadcrumb_navxt_settings = array_merge($bcn_options, $breadcrumb_navxt_settings);
	}
	update_option( 'bcn_options', $breadcrumb_navxt_settings );

	/**** START - Edit "Hello World" post and change *****/
	$hello_world_post = get_post(1);
	if( !empty($hello_world_post) ){
		$newDate = array(
			'ID'		=> '1',
			'post_date'	=> "2014-12-10 0:0:0" // [ Y-m-d H:i:s ]
		);
		
		wp_update_post($newDate);
	}
	
	$theme_options = array();
	
	$theme_options['overlay']	= 'eNrtPWtv20iSny9A_kOvBndIbkxbfOgZxzvZbGZ2gd3JXFzi4O5wWBAtsiVxTJFcXJKyown836-qX-ymSNme2IEN7DgZS83q6np0dz26mqFzb-bNv1Tz2XxQXSRZlKd5OXhVzVwn88F3SzaajCb4zQ3gMYvyLKblzoIZ8v84zMyAcVYlswGXdDlZBvhtPB-kdJdva_wynQ-W2zS9SmLGkcjvITaELGUbltXV4BWdu_MvyXwouq8ZjRlgvoYOgHuV5guahgsaXazKfJvFCD9BrkbzQbKhK456OB9IWnhTEhuNgLNkBaO10QaUFHmV1EmeGa0u_KZ1TaM1UmY8QAklv5kjweC2BPh_gmoYMMkyVj4pogH5qqRxAjhCDhTmGeuYLPtw9VW-Pw9gvqQ5KjLZrExip007sBxG26rONyaAB_gZCA90vsyRH4ocfuESWdJNku4k-re0phtaUi4L158PUNrbwmmAPOhyTtf5hh6Rn1ww5yX8rmhWORUMv5Q0X9IyoUJuE5T5apvSUi2Lmn2unRrGqJZ5aZIJ4yN1jhIwUO1OeS8XGEwy5qxZslrX8pk3VRhTVtesdKqCRknGJQMdhl3KmVD8UTKhaeogqWLFcKRiFgSCEjlnVnm-ShnXqAekLlKQSVKtw8W2rvOsb3EPOc0Xjn4OmBrNcJ3px44hohaasQW3zi9Z124DfK7dEFc5CEDreLanYmDs405MwW7tAllvQHfpEfkLSy9ZnUQ36BewjCWpd9StP-rXbTC6u24bofWqj8vJe2py8g_IyX84OflPTU7DA3IaPpycglwnJlwn74Cc_AeU0-iJyem-bc9t5TR-anI6sI977sPIyRMu7dMR0uiAkMYPZ-yq7eIxygkEtC0KVka0Yn2zKjgwq4K7C6xxlg7OKojGavTC-6V1Oy_5zlwie6x-cr-0oC_EnCtWPxW7d2BG-cHDLEGgVobkYZ3U2EoB5PFbvV6OsMeClmG1zq8GrxZzV9KMjY4ZSAM9MVvSbVoPDJBwsQp7AqKRgjgc309BHeu6Lqr5yclyCzFtkh8XJdsB4yxaZ3m1q46jfHNyVThyLZ9sC4yOqxNv6HlcJ653soSvNSgXSV6sjguhZjtjXDACGAVTby9rXDD8Z7nTfP_96QM-nWQ0dyiHoOSCSmxkB-PGtLzApBFXnGdBcamGFso49n0ZSUwk7JpmccrKMIkE8T4MdZqQKKVV9XpQlLUjBewghFOvB2enXCfJGR_P78ARRmku9nN_ehCTgNPINIsCiaI6ECxaJC_qrH8KeUELqiUGnIQlaP3F8Ij_vOSd1OByLwPo7SYLm3wbdJqGgRayOXdKRi-KPBEahsFdT6w5b9YH6DTUGvAogDov2uujQ8cG1G2YQ7nJLvb0gQGv1knNlNgsoBZmz9WYCfzxRiP4feyNhPiGdmfcNfat-FgDpWxZc0jBEfQ-3aZqolwwDF-0NKphdqTJ2Slsw5k5jZqM69nf8qimsOzInJyeINwZyy5hF8jJ-p_EC8gyWdbrI0KBm5KmCT09QYQ3IH23oUnaYDylZF2y5esBNtf5PMmW-Q_sM90UKcNdZnDWbjk9oWdipJNtetbSQYkWR3Pvjka_n_tzml6Q85y8-wxuVN1Bcc1ScGj8YDSeTGfDwdn3Q5e8cAP_JYEmAm0zTer_cdx5BAbGwVxcU_WPDuIPzPagA6ZnoiM6tIOHTcHMhDpsDiajrzQH7oka6vjXotsQeCNB_V0MAS7HCEZjJRG_vtYsoFD4KsT1p_7iKr-WNl4JrKp3KeuwwKZQ7c3A2GhxrWuoxxg5oAgjWiQ1LOnf-mKHybjf05uO-z29now-TJSZtzycF7Y08DiDrm8XPdxVYLhtxFG53Sye3lxcc8f3K7vxdMwm_o1RhZbdZcKuOlb7yFrHiiYfs-560zbEvsjLGM_W8prvwdKvnyiY7eaA1zW2MXW4JmPbNTkeSdfLnANrPL5s8EgJZrnihsaXYY2AEQTfZaS2NAjF2Sovd-RNGa2TS1bNyV6Pmq5Uj1wwD69WLWB0ZjUwbOI1N7nJMmGxXCLzF2itSNNOwB6xUo41NbrTbb3OSzUcCPANb2iT56sjWVs5buMPysf9YvcsmLbI-6yF0BfYF1xcHmmoMDyWM9Wbrd_4yA-O_BnMookvrJ-Pni-rijyrQMJhv1DsoB33Cwlr9LZDENNN5oesq7zeFYrSJiaVj6RjN8ZpWSS_UX1mu8oPbGwTnF5FkWTVo0lcJ3mHNrXJg6RKJkJO_GSbwlr4wgdrgnF_5kpi6zXsD862TDn28VenA3BYBx2g4-pyZVRYPNwQMqzn82JDP4eWfEe6NkQ8zxf7MPJ4FKZKBVPhYheq-g6xcWNYZW0voVwws3cZ3EGs7geDz1kXcO-u4x6JP8Pj2filni9Cv5qYbjV7nWqe3I8OUpRGn57vf4xrIeWWog1tNPpGZTCwG-swyYptrRR0DtsN-W-wzuR8zTLyDkOJ42NlVUUPXFzPKr3Y7LYzPQck3sWKpunX7e_3E_RgxiX5zOK77v3-6Ej8gVk1eqmT0IJLHfbgyhKGOnIQXUp3ajOT8tABuA8CPo2TSxVji-dKu4OOXDDcrugSUfiPJWO3CMBfQAT-EhpU_D0U8TcMf6YdMumFsTS_UsuMgkvUkQ3D_KsEEWUo2mlrzJp40LALingr8gvk00cV7dmwGP7L5RDcctuTKQvHPelGuVh1BprNFgXTYhua0wgUWOrNrnFzqjTBX5hBUizJOYrIMBFTASEXKoNcJyutXFzMEHQomVwnPc-I-UQ0NXnLi6sw4nacLFNa88xlsQa0ToQLiacvhf7k_w_NpLV_ds5SxvufnsC30_Xo7HucDpPZiMymgQutI3M-dPEkq8Lc6fAeeWLZJUy4gt2dI5EtexPH4EBVmqv9lJjNmNfFGKwZoa6Zd5_qSmnE1nmKtvHO3L1fLpOI7bFHQGd_YumSVjWhl-yI_AizO4npQf1xvTd5T5ySap_4bnD207tz8l-f3p-_wy1BbQZy1su09IH0rWetJNwvbGdhPOxacIds_WQf9KaQzndfqq62m3DTYH7Q26Odhx7KMV1vBr7F6Gg8xijgpTRdaGQrlqudbu2u8w3LM-FAo1EQePuymLipbtiKXCIUtxslL7CVDpW3171cJ8GJgDTJEPjppTK-fcGLp11YU2qdZ2FcInJVYCGYHIzX0GBZmUzMkXOJ-H3AB6NCnNhxmRdxfnWDEh-oDuArsniHgrbxg9RcMHhSWv0asXIWqJNu8A6dGNWtM6PbfaUqbnJlh9qVrfPins90_WFcJ0NGHuKJ8abWT5s3brWM7ErfwvabRVwntv-KFbCuarnxqzwgOpdqj9aGUZVVfKPEio8R2_2vz4epu0SBdU009_FdneBNB0j2nh7J_tMjOXh6JI-eHsnjp0fy5OmRPH16JM8eMclejykZPmKauWHMwZ6GUU07S7vG4ViXdjWQi_yzhHbNNFMfkHcbIL-VnDWBjPC4fa0UXewWaMtZDvDyoIzcXQv4QNJgKG-NSmiTAvRQuEsDLpiUur5k2oA_klxc8u39VDUp3EZBPaUyXFzkSVnVit29iQPwfsh_tNRN-APpDq75Fuw3FKU64P96l98bebHv6SDe4unAvGuzL7148PdZh78_URekezUByIMwaOozbfAbpjWugr0Oj3Zi9903Hi2nS6r3O5uffk34e7wfVAUelejjifqKsUx2k72MY4pMZt493gXnW5c67GKGYQfo4z6t6tGGO8YfrQ2bqQPrwti482JcJwpF8aRDlLxP7Jw4HkWVDIl2MIuCafDnz4xKUjGqIxCSFvQlCIBV2IP8216VqYimz_5THma9VbRUP-ARXCf5ccsvkZM_7cgv_CjoXFwfBb1JU_KBg5IPDGLnSxbz4tJ_DfOvYb7VMLxsGX-ZZ017y0qfLSqPbaK3NrrIeZZKgXbsamhG5Mmmyg1_ows9k7vcqDucSjpYlqmOjfNC7l4FjWOJQKeqxIlInGBlYCMNM9vlq_MQ-bxaU1E5hXUL_8RzKnXsYpw9h_oFB2OlFOWRaa_YPNfuvCwywnc05Cux3abJJlES9Kacdt8VXDCySoDfZQKlb_g1rWy7WTSVNOj4clxcWJi4ycvmDA8E_gHayN_zUp2ncECjHlPiV-rAx004IElSs8prnisMyDM6qO7AIAQBbL6aEz6f2zew4LyUHwWO9LbqQlCU-1C4jJKI8ffGBOq9Mej004gt8hzkmnB5YP3-VVJzY5nMPcF3kaD1ZFWNbb6shwNlwvTIdLhrCnzDIDhJk4qvHv4yHcDLMrpIWazLgoBOUUwpZfFGf-G6FnYTPv5ZfkSBCx1KW_9WfKs4CeiGXCeVHoEPimW0dCXRnNNVJXUS0aZeQpSXosF8dX0t94o2XCdIDK5DK6D1gg5IGA4Fo48Vu2BgdAuma0QhGBPMnTTz4ybxqqY-cXVLeF-I_u8QYr9er2UkYXHRLdphC6ot1vbztkjbo-yLE0_oi7ysl3ma5GFR5r-yqA5jXDBO0qoVyDdwuHJ1TBmIkLlZmQqqZClwFTcrE88cP4hGMHZ8qEpfvJLAV3l5EbMqCtulL0EX6maLwTpwVVuBe_Y-rLjJyW2Dr4_Z26NGNTW5RukslThw42ZyPuDGIVwnGFLfAmpYxqMZwWkz3WgrLLjGLec2yEAHRNWBH0Tn3RodeZsm9mLYQ3ctzHgj0O5tF0T1ca2M3RCHhdnYs8d76nG3_pruhs5mupKe0U0Ik6OkFl-VXFzxpmZmvdDGpMT4sGDIUlLvbqmlWyEGovmtNRBwxMhhCaNIEGO_zIIGoEdqBoo9uU3Esw1Do68I5jZWkYvL4RdWVnkG3uhfM7EZqQhyKvm90TvgJXvSxoYmM1PJjPIDZi04y1lQ5V9tZHtsuRrgZtJwV2BlmZfBMAgTulkx5WOIvQlrldbBWWAGoBzeSTYrZ-hiCdZmpYuyoG2ZbiEoXCdVGb3-2oJaoMkpIMjnl7QJTevXA2zSI3NPPzg9AQKVZDQvi2Rl3LUELQIe8nNekx8xcf0HpVxcDS_dWdUFL5p_zMtyd0TqdVIRJINs6I6saUUWjGVkA75qfERiBo42bN15iY8XjOzyLfkVJjHZJJWD9wViwMDIpw9_O1aLVQ-KWL9ZTYNcJwsr7zujGqhK5AzmVKWuIOEsxDo6EPkawgeyRAZFGV1xJiULrjzJ5HNYV9EaZAXiK4nAR4DKTXVMfkkZxDWkLneErmiSEfBB16TKN4zEyXLJMKFHLtgO7FVcXB2fnhRnuqY6iZm61tOuLbWeS1lbz2fNc77MxTZhpyhHnTAhqrOQclR5HL5uNT3SbNjYxh0QuMRN26bRGUPL1d6C4PlAG6IXmQWKsrdvYBmiuMpz7jmW0Z7EeFJRYQGdpozP7wM9TCYWiwIrLfdADNLYpbLKFgQKVlhfLPustPMbWHaPMyGNtJRGRjfqBk8T6nRCCu8QZOY1ZdFXV1fHqhvfyVq7mzuz7eMBAszA6uD4vnHhWfbgQ7eyJHxg_3acN7HawZFHvs256saHTzLJvKO5d4rL2knr-ITTEtyClhmWzFbgzZd0c5MaWsTofoYeQk3KifQmYCZdRY5ZUmzE-cYsdRqzq93iFgTEBPE2qh1wZBy1eSj7y2cs2GRnnYME6IKlehws7FWNjjI1wMtf8mY5YM-KpszuirZKDhri0zBlC3UZTaaENAbdWQ-BGSmaaoMPUhDr0-GjSX_fjEsbCPmwSyZ-N9xWnhpKMFTjFtdlXW55urrxrjAVc47WFawUI_D7E96rJG8NYOVo2RjW9UaEVjgrTddkmzlY9sl10tRzP3_Wgul6LF6EgHXE_xCOhd2rYgWPdM70w7Vr1o9jiuzs089_fveBvH3_88fzD5_env_1_c9g8VxcDhxoRPp--Fww7CBEoNz80SvGDRp3Nq7Az4CpxsD2fazhcw3uU_wH7ueo_KaV5wza8nm6ZZIL_NElBzZXUQUOby5efDzzgdAfkg3aSbIt0xeNr4mZyGOR1aRFXCKvqVTVH0UC9vX7gmXff6QZ2qvhEfxNjgL4EOCHMXwY44cJfIC_yeDlq-fPFnm8-_L8mUyEzskQ2ja0XFwlmfh8TZ4_O5Y6PVwix42Cv8ADXgcohp6TwVwwR1wnOPrgiBzKAbfQfpGIUIZzMh4WnwHAKCSEthG0QQ877TtcJy4HNckVnx2R3p0_f4bIiN1I3Cnvxse8UiMMsXcbv8cBuRLn5Dtv6sejKTQQTr0hCosBz99nwB9amKbeNJqNX92GIYvKDEO0VImvaz9ArahZPFwndFHBzlYzPtISEIyG_w6fYT7PSTDCj84FbjdNwn1O-Efc7v7nhQPgL5uG_xUN2GuT_3a3PgQ7VXceXCe_a487gpNrkCO__hbx3RHF15otgVBdnFRFSmGaXCcZ1-xcIs2jC9SEfpVxDr2-fbxzf2UPywn-6NcwFMsQbbCVPHq_SOqtynbynJsJxP1idS-7De0a0FW6XUmYvAMG434rSaERETvfKnNdGt5cIlwwDeteR31fUnZTlCCwJsUxAwl8ojw0Wx4gs49NbOJNuuAsiuwObruDoqVpb4NZgkHCJLq2WMYdXWzZjPf67pqLt01PLZ6m3RbOSGaJbMmgHs-hmfydR4yVlcfrEQ4qxehjJsBs8fBiF2h1mpCVv4QLAXloaufjOM6fsL1SQW0b1KZjaPaxmBRdNB1DSYeOh3HVYPoGFxvuD811_xF_n2S9Vi9dm6iXLlmvyAjG6gQzKoXHAY07VukX7lvIHRHfdo8wGU86R5i2R5BhsPzHE-wBuNvTjX886uRg5N6WAyNJ0DOC2znCZHRgBH4xUY1gzZHuMYIeLoaHuMA7nhE_012UtNwZOWgVcWLpUWUeK67ZJlnu9MsRVJWj4fGp04dAP_11_6HuiiabXykUiw1vzGLwKG9d3uQrespZlDdI5nh17ugK-P-Be4qvuHf4ysXP_yHN3uvqihYDAnHQa5HUrdaMQXShdmiDLnQoIWAt69Y_49ACYZlp-3BcJxcG9IBwZnuiC6Vn3lhQ4TS3erX-AQr1gs-hlDiE1OLfmLCfiCNskcaseDGTfODKO-rizXCqGSNG9Q5DUXKBsYp-69BQnd417xPae268O0clquQD_T4LUfJhUm9X5OqhrAMxTq4RCQ97j8xU8t4oIGmhMc-CFC6MdXtOi5rjd0nyyEgRt7hs1oZMilnnkX4rZFLd8OpkkvEFJjnDTAS-cylmmzxUrz3Oi6bT9f8D1iY7Hg';
	$theme_options['classic']	= 'eNrtPWtv20iSny9A_kOvBndIbkxbfOgZxzvZbGZ2gd3JXFzi4O5wWBAtsiVxTJFcXJKyown836-qX-ymSNme2IEN7DgZS83q6np0dz26mqFzb-bNv1Tz2XxQXSRZlKd5OXhVzVwn88F3SzaajCb4zQ3gMYvyLKblzoIZ8v84zMyAcVYlswGXdDlZBvhtPB-kdJdva_wynQ-W2zS9SmLGkcjvITaELGUbltXV4BWdu_MvyXwouq8ZjRlgvoYOgHuV5guahgsaXazKfJvFCD9BrkbzQbKhK456OB9IWnhTEhuNgLNkBaO10QaUFHmV1EmeGa0u_KZ1TaM1UmY8QAklv5kjweC2BPh_gmoYMMkyVj4pogH5qqRxAjhCDhTmGeuYLPtw9VW-Pw9gvqQ5KjLZrExip007sBxG26rONyaAB_gZCA90vsyRH4ocfuESWdJNku4k-re0phtaUi4L158PUNrbwmmAPOhyTtf5hh6Rn1ww5yX8rmhWORUMv5Q0X9IyoUJuE5T5apvSUi2Lmn2unRrGqJZ5aZIJ4yN1jhIwUO1OeS8XGEwy5qxZslrX8pk3VRhTVtesdKqCRknGJQMdhl3KmVD8UTKhaeogqWLFcKRiFgSCEjlnVnm-ShnXqAekLlKQSVKtw8W2rvOsb3EPOc0Xjn4OmBrNcJ3px44hohaasQW3zi9Z124DfK7dEFc5CEDreLanYmDs405MwW7tAllvQHfpEfkLSy9ZnUQ36BewjCWpd9StP-rXbTC6u24bofWqj8vJe2py8g_IyX84OflPTU7DA3IaPpycglwnJlwn74Cc_AeU0-iJyem-bc9t5TR-anI6sI977sPIyRMu7dMR0uiAkMYPZ-yq7eIxygkEtC0KVka0Yn2zKjgwq4K7C6xxlg7OKojGavTC-6V1Oy_5zlwie6x-cr-0oC_EnCtWPxW7d2BG-cHDLEGgVobkYZ3U2EoB5PFbvV6OsMeClmG1zq8GrxZzV9KMjY4ZSAM9MVvSbVoPDJBwsQp7AqKRgjgc309BHeu6Lqr5yclyCzFtkh8XJdsB4yxaZ3m1q46jfHNyVThyLZ9sC4yOqxNv6HlcJ653soSvNSgXSV6sjguhZjtjXDACGAVTby9rXDD8Z7nTfP_96QM-nWQ0dyiHoOSCSmxkB-PGtLzApBFXnGdBcamGFso49n0ZSUwk7JpmccrKMIkE8T4MdZqQKKVV9XpQlLUjBewghFOvB2enXCfJGR_P78ARRmku9nN_ehCTgNPINIsCiaI6ECxaJC_qrH8KeUELqiUGnIQlaP3F8Ij_vOSd1OByLwPo7SYLm3wbdJqGgRayOXdKRi-KPBEahsFdT6w5b9YH6DTUGvAogDov2uujQ8cG1G2YQ7nJLvb0gQGv1knNlNgsoBZmz9WYCfzxRiP4feyNhPiGdmfcNfat-FgDpWxZc0jBEfQ-3aZqolwwDF-0NKphdqTJ2Slsw5k5jZqM69nf8qimsOzInJyeINwZyy5hF8jJ-p_EC8gyWdbrI0KBm5KmCT09QYQ3IH23oUnaYDylZF2y5esBNtf5PMmW-Q_sM90UKcNdZnDWbjk9oWdipJNtetbSQYkWR3Pvjka_n_tzml6Q85y8-wxuVN1Bcc1ScGj8YDSeTGfDwdn3Q5e8cAP_JYEmAm0zTer_cdx5BAbGwVxcU_WPDuIPzPagA6ZnoiM6tIOHTcHMhDpsDiajrzQH7oka6vjXotsQeCNB_V0MAS7HCEZjJRG_vtYsoFD4KsT1p_7iKr-WNl4JrKp3KeuwwKZQ7c3A2GhxrWuoxxg5oAgjWiQ1LOnf-mKHybjf05uO-z29now-TJSZtzycF7Y08DiDrm8XPdxVYLhtxFG53Sye3lxcc8f3K7vxdMwm_o1RhZbdZcKuOlb7yFrHiiYfs-560zbEvsjLGM_W8prvwdKvnyiY7eaA1zW2MXW4JmPbNTkeSdfLnANrPL5s8EgJZrnihsaXYY2AEQTfZaS2NAjF2Sovd-RNGa2TS1bNyV6Pmq5Uj1wwD69WLWB0ZjUwbOI1N7nJMmGxXCLzF2itSNNOwB6xUo41NbrTbb3OSzUcCPANb2iT56sjWVs5buMPysf9YvcsmLbI-6yF0BfYF1xcHmmoMDyWM9Wbrd_4yA-O_BnMookvrJ-Pni-rijyrQMJhv1DsoB33Cwlr9LZDENNN5oesq7zeFYrSJiaVj6RjN8ZpWSS_UX1mu8oPbGwTnF5FkWTVo0lcJ3mHNrXJg6RKJkJO_GSbwlr4wgdrgnF_5kpi6zXsD862TDn28VenA3BYBx2g4-pyZVRYPNwQMqzn82JDP4eWfEe6NkQ8zxf7MPJ4FKZKBVPhYheq-g6xcWNYZW0voVwws3cZ3EGs7geDz1kXcO-u4x6JP8Pj2filni9Cv5qYbjV7nWqe3I8OUpRGn57vf4xrIeWWog1tNPpGZTCwG-swyYptrRR0DtsN-W-wzuR8zTLyDkOJ42NlVUUPXFzPKr3Y7LYzPQck3sWKpunX7e_3E_RgxiX5zOK77v3-6Ej8gVk1eqmT0IJLHfbgyhKGOnIQXUp3ajOT8tABuA8CPo2TSxVji-dKu4OOXDDcrugSUfiPJWO3CMBfQAT-EhpU_D0U8TcMf6YdMumFsTS_UsuMgkvUkQ3D_KsEEWUo2mlrzJp40LALingr8gvk00cV7dmwGP7L5RDcctuTKQvHPelGuVh1BprNFgXTYhua0wgUWOrNrnFzqjTBX5hBUizJOYrIMBFTASEXKoNcJyutXFzMEHQomVwnPc-I-UQ0NXnLi6sw4nacLFNa88xlsQa0ToQLiacvhf7k_w_NpLV_ds5SxvufnsC30_Xo7HucDpPZiMymgQutI3M-dPEkq8Lc6fAeeWLZJUy4gt2dI5EtexPH4EBVmqv9lJjNmNfFGKwZoa6Zd5_qSmnE1nmKtvHO3L1fLpOI7bFHQGd_YumSVjWhl-yI_AizO4npQf1xvTd5T5ySap_4bnD207tz8l-f3p-_wy1BbQZy1su09IH0rWetJNwvbGdhPOxacIds_WQf9KaQzndfqq62m3DTYH7Q26Odhx7KMV1vBr7F6Gg8xijgpTRdaGQrlqudbu2u8w3LM-FAo1EQePuymLipbtiKXCIUtxslL7CVDpW3171cJ8GJgDTJEPjppTK-fcGLp11YU2qdZ2FcInJVYCGYHIzX0GBZmUzMkXOJ-H3AB6NCnNhxmRdxfnWDEh-oDuArsniHgrbxg9RcMHhSWv0asXIWqJNu8A6dGNWtM6PbfaUqbnJlh9qVrfPins90_WFcJ0NGHuKJ8abWT5s3brWM7ErfwvabRVwntv-KFbCuarnxqzwgOpdqj9aGUZVVfKPEio8R2_2vz4epu0SBdU009_FdneBNB0j2nh7J_tMjOXh6JI-eHsnjp0fy5OmRPH16JM8eMclejykZPmKauWHMwZ6GUU07S7vG4ViXdjWQi_yzhHbNNFMfkHcbIL-VnDWBjPC4fa0UXewWaMtZDvDyoIzcXQv4QNJgKG-NSmiTAvRQuEsDLpiUur5k2oA_klxc8u39VDUp3EZBPaUyXFzkSVnVit29iQPwfsh_tNRN-APpDq75Fuw3FKU64P96l98bebHv6SDe4unAvGuzL7148PdZh78_URekezUByIMwaOozbfAbpjWugr0Oj3Zi9903Hi2nS6r3O5uffk34e7wfVAUelejjifqKsUx2k72MY4pMZt493gXnW5c67GKGYQfo4z6t6tGGO8YfrQ2bqQPrwti482JcJwpF8aRDlLxP7Jw4HkWVDIl2MIuCafDnz4xKUjGqIxCSFvQlCIBV2IP8216VqYimz_5THma9VbRUP-ARXCf5ccsvkZM_7cgv_CjoXFwfBb1JU_KBg5IPDGLnSxbz4tJ_DfOvYb7VMLxsGX-ZZ017y0qfLSqPbaK3NrrIeZZKgXbsamhG5Mmmyg1_ows9k7vcqDucSjpYlqmOjfNC7l4FjWOJQKeqxIlInGBlYCMNM9vlq_MQ-bxaU1E5hXUL_8RzKnXsYpw9h_oFB2OlFOWRaa_YPNfuvCwywnc05Cux3abJJlES9Kacdt8VXDCySoDfZQKlb_g1rWy7WTSVNOj4clxcWJi4ycvmDA8E_gHayN_zUp2ncECjHlPiV-rAx004IElSs8prnisMyDM6qO7AIAQBbL6aEz6f2zew4LyUHwWO9LbqQlCU-1C4jJKI8ffGBOq9Mej004gt8hzkmnB5YP3-VVJzY5nMPcF3kaD1ZFWNbb6shwNlwvTIdLhrCnzDIDhJk4qvHv4yHcDLMrpIWazLgoBOUUwpZfFGf-G6FnYTPv5ZfkSBCx1KW_9WfKs4CeiGXCeVHoEPimW0dCXRnNNVJXUS0aZeQpSXosF8dX0t94o2XCdIDK5DK6D1gg5IGA4Fo48Vu2BgdAuma0QhGBPMnTTz4ybxqqY-cXVLeF-I_u8QYr9er2UkYXHRLdphC6ot1vbztkjbo-yLE0_oi7ysl3ma5GFR5r-yqA5jXDBO0qoVyDdwuHJ1TBmIkLlZmQqqZClwFTcrE88cP4hGMHZ8qEpfvJLAV3l5EbMqCtulL0EX6maLwTpwVVuBe_Y-rLjJyW2Dr4_Z26NGNTW5RukslThw42ZyPuDGIVwnGFLfAmpYxqMZwWkz3WgrLLjGLec2yEAHRNWBH0Tn3RodeZsm9mLYQ3ctzHgj0O5tF0T1ca2M3RCHhdnYs8d76nG3_pruhs5mupKe0U0Ik6OkFl-VXFzxpmZmvdDGpMT4sGDIUlLvbqmlWyEGovmtNRBwxMhhCaNIEGO_zIIGoEdqBoo9uU3Esw1Do68I5jZWkYvL4RdWVnkG3uhfM7EZqQhyKvm90TvgJXvSxoYmM1PJjPIDZi04y1lQ5V9tZHtsuRrgZtJwV2BlmZfBMAgTulkx5WOIvQlrldbBWWAGoBzeSTYrZ-hiCdZmpYuyoG2ZbiEoXCdVGb3-2oJaoMkpIMjnl7QJTevXA2zSI3NPPzg9AQKVZDQvi2Rl3LUELQIe8nNekx8xcf0HpVxcDS_dWdUFL5p_zMtyd0TqdVIRJINs6I6saUUWjGVkA75qfERiBo42bN15iY8XjOzyLfkVJjHZJJWD9wViwMDIpw9_O1aLVQ-KWL9ZTYNcJwsr7zujGqhK5AzmVKWuIOEsxDo6EPkawgeyRAZFGV1xJiULrjzJ5HNYV9EaZAXiK4nAR4DKTXVMfkkZxDWkLneErmiSEfBB16TKN4zEyXLJMKFHLtgO7FVcXB2fnhRnuqY6iZm61tOuLbWeS1lbz2fNc77MxTZhpyhHnTAhqrOQclR5HL5uNT3SbNjYxh0QuMRN26bRGUPL1d6C4PlAG6IXmQWKsrdvYBmiuMpz7jmW0Z7EeFJRYQGdpozP7wM9TCYWiwIrLfdADNLYpbLKFgQKVlhfLPustPMbWHaPMyGNtJRGRjfqBk8T6nRCCu8QZOY1ZdFXV1fHqhvfyVq7mzuz7eMBAszA6uD4vnHhWfbgQ7eyJHxg_3acN7HawZFHvs256saHTzLJvKO5d4rL2knr-ITTEtyClhmWzFbgzZd0c5MaWsTofoYeQk3KifQmYCZdRY5ZUmzE-cYsdRqzq93iFgTEBPE2qh1wZBy1eSj7y2cs2GRnnYME6IKlehws7FWNjjI1wMtf8mY5YM-KpszuirZKDhri0zBlC3UZTaaENAbdWQ-BGSmaaoMPUhDr0-GjSX_fjEsbCPmwSyZ-N9xWnhpKMFTjFtdlXW55urrxrjAVc47WFawUI_D7E96rJG8NYOVo2RjW9UaEVjgrTddkmzlY9sl10tRzP3_Wgul6LF6EgHXE_xCOhd2rYgWPdM70w7Vr1o9jiuzs089_fveBvH3_88fzD5_env_1_c9g8VxcDhxoRPp--Fww7CBEoNz80SvGDRp3Nq7Az4CpxsD2fazhcw3uU_wH7ueo_KaV5wza8nm6ZZIL_NElBzZXUQUOby5efDzzgdAfkg3aSbIt0xeNr4mZyGOR1aRFXCKvqVTVH0UC9vX7gmXff6QZ2qvhEfxNjgL4EOCHMXwY44cJfIC_yeDlq-fPFnm8-_L8mUyEzskQ2ja0XFwlmfh8TZ4_O5Y6PVwix42Cv8ADXgcohp6TwVwwR1wnOPrgiBzKAbfQfpGIUIZzMh4WnwHAKCSEthG0QQ877TtcJy4HNckVnx2R3p0_f4bIiN1I3Cnvxse8UiMMsXcbv8cBuRLn5Dtv6sejKTQQTr0hCosBz99nwB9amKbeNJqNX92GIYvKDEO0VImvaz9ArahZPFwndFHBzlYzPtISEIyG_w6fYT7PSTDCj84FbjdNwn1O-Efc7v7nhQPgL5uG_xUN2GuT_3a3PgQ7VXceXCe_a487gpNrkCO__hbx3RHF15otgVBdnFRFSmGaXCcZ1-xcIs2jC9SEfpVxDr2-fbxzf2UPywn-6NcwFMsQbbCVPHq_SOqtynbynJsJxP1idS-7De0a0FW6XUmYvAMG434rSaERETvfKnNdGt5cIlwwDeteR31fUnZTlCCwJsUxAwl8ojw0Wx4gs49NbOJNuuAsiuwObruDoqVpb4NZgkHCJLq2WMYdXWzZjPf67pqLt01PLZ6m3RbOSGaJbMmgHs-hmfydR4yVlcfrEQ4qxehjJsBs8fBiF2h1mpCVv4QLAXloaufjOM6fsL1SQW0b1KZjaPaxmBRdNB1DSYeOh3HVYPoGFxvuD811_xF_n2S9Vi9dm6iXLlmvyAjG6gQzKoXHAY07VukX7lvIHRHfdo8wGU86R5i2R5BhsPzHE-wBuNvTjX886uRg5N6WAyNJ0DOC2znCZHRgBH4xUY1gzZHuMYIeLoaHuMA7nhE_012UtNwZOWgVcWLpUWUeK67ZJlnu9MsRVJWj4fGp04dAP_11_6HuiiabXykUiw1vzGLwKG9d3uQrespZlDdI5nh17ugK-P-Be4qvuHf4ysXP_yHN3uvqihYDAnHQa5HUrdaMQXShdmiDLnQoIWAt69Y_49ACYZlp-3BcJxcG9IBwZnuiC6Vn3lhQ4TS3erX-AQr1gs-hlDiE1OLfmLCfiCNskcaseDGTfODKO-rizXCqGSNG9Q5DUXKBsYp-69BQnd417xPae268O0clquQD_T4LUfJhUm9X5OqhrAMxTq4RCQ97j8xU8t4oIGmhMc-CFC6MdXtOi5rjd0nyyEgRt7hs1oZMilnnkX4rZFLd8OpkkvEFJjnDTAS-cylmmzxUrz3Oi6bT9f8D1iY7Hg';
									
	if ( !function_exists( 'tm_cs_decode_string' ) ) {
		function tm_cs_decode_string( $string ) {
			
			// decode the encrypted theme opitons
			$options = unserialize( gzuncompress( stripslashes( call_user_func( 'base'. '64' .'_decode', rtrim( strtr( $string, '-_', '+/' ), '=' ) ) ) ) );
	
			
			// changing image path with client website url so image will be fetched from client server directly
				$demo_domains = array(
									'https://minemo.preyantechnosys.com/',
								);
				
				// getting current site URL
				$current_url = get_site_url() . '/';
				
			foreach( $options as $key=>$val ){
					if( !empty($val) && is_string($val) ){
						if( substr($val,0,7) == 'http://' ){
							$val = str_replace( $demo_domains, $current_url, $val );
							$options[$key] = $val;
						}
					}
				}
		
			return $options;
		}
	}
					
		$new_options = tm_cs_decode_string( $theme_options[$selected_import['import_file_name']] );
		
		update_option('minemo_theme_options', $new_options);
	

	
	
  }
}
add_action( 'ocdi/after_import', 'minemo_demo_after_import' );

?>
